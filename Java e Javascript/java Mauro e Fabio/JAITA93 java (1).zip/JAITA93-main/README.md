# JAITA93
Repo del corso Generation JaIta 93

Sono un commento sulla macchina locale di mauro
